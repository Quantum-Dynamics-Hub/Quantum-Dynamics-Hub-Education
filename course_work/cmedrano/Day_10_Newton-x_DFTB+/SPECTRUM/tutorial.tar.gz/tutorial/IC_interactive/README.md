folder to generate the initial conditions 
