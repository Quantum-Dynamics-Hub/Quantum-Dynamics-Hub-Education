folder to calculate the modes with dftb+
