folder to optimize the geometry using dftb+
