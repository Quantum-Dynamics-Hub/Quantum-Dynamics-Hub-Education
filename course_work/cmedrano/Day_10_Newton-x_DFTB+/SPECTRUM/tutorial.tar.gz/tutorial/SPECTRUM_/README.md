This folder contains the spectrum generated 
after run all the trajectories
