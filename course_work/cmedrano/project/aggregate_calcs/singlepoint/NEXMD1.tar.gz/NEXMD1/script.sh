#! /bin/bash


for dir in */; do
    cd $dir
    nexmd.exe > md.out
    cd ../
    echo "$dir"
done
