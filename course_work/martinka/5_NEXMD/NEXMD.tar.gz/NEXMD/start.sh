#!/bin/bash
for i in `seq $1 $2`; do
    cd TRAJ_$i
        sbatch submit.slm
    cd ..
done


