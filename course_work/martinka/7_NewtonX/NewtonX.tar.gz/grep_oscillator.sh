#!/bin/bash

for i in `seq 2 11`; do
   echo -n "$i "
   cat final_output.1.$i | grep "Oscillator strength:" | sort -k3,3 -u | tail -1
done

