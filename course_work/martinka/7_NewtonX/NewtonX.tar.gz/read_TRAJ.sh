#!/bin/bash
for i in `seq $1 $2`; do
    echo -en "TRAJ$i:  \t" #e-enable interpretation of backslash escapes, n-without new line
    if [[ TRAJ$i/RESULTS/dyn.out ]]; then
        cat TRAJ$i/RESULTS/dyn.out | grep STEP | tail -1
    fi
done
