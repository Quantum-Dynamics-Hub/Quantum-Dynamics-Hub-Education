#!/bin/bash
for i in `seq $1 $2`;do 
  cd TRAJ$i
    rm -r DEBUG INFO_RESTART RESULTS TEMP
    rm *.out *.log
  cd ..
done
